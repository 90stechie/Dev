
  # Portfolio Showcase

  This is a code bundle for Portfolio Showcase. The original project is available at https://www.figma.com/design/RCZ1A2AFxLqxvW0ycgL965/Portfolio-Showcase.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  